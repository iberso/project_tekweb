# sorttable.js
jQuery plug-in that allows you to sort table by any column
Requires: jQuery (tested with v 1.11)

# Usage
`$("#dest").addSortWidget(options);` // add rating widget to div container wich ID is 'dest'

# Options
JS object

Option | Type | Description
------ | ------ | ------ 
`img_asc` | string | path to 'ascending sort' image 
`img_desc` | string | path to 'descending sort' image 
`img_asc` | string | path to 'no sort' image 
